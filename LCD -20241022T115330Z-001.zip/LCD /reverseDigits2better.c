#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef unsigned char u8; 
typedef signed int  s32;

void LCD_Displayer(s32 num){
    char displayed_array[12]; // Enough to store digits of a 32-bit int and a '-' sign
    u8 i = 0;

    if (num < 0) {
        displayed_array[i++] = '-';// assignation is before increment... remeber
        num = -num;
    }

    s32 temp = num;
    u8 digits = 0;
    
    do {
        digits++;
        temp /= 10;
    } while (temp != 0);

    displayed_array[digits + i] = '\0'; // Null-terminate the string

    while (num != 0) {
        displayed_array[digits - 1 + i] = (num % 10) + '0'; // Extract the last digit and convert to char
        num /= 10;
        digits--;
    }

    printf("%s\n", displayed_array);
}

int main() {
    printf("Enter your number\n");
    s32 num;
    scanf("%d", &num);
    
    LCD_Displayer(num);

    return 0;
}
