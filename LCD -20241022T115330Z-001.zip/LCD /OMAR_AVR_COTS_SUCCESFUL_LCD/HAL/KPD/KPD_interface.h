/*********************************************
 * Author:				Abdullah M. Abdullah
 * Creation Data:		29 Sep, 2023
 * Version:				v1.0
 * Compiler:			GNU AVR-GCC
 * Controller:			ATmega32
 * Layer:				HAL
 ********************************************/
/*********************************************
 * Version	  Date				  Author				  Description
 * v1.0		  29 Sep, 2023	Abdullah M. Abdullah		  Initial Creation
*********************************************/
#ifndef KPD_INTERFACE_H
#define KPD_INTERFACE_H

void KPD_voidInit(void);
u8 KPD_u8GetPressedKey(void);



#endif