/*********************************************
 * Author:				Abdullah M. Abdullah
 * Creation Data:		29 Sep, 2023
 * Version:				v1.0
 * Compiler:			GNU AVR-GCC
 * Controller:			ATmega32
 * Layer:				HAL
 ********************************************/
/*********************************************
 * Version	  Date				  Author				  Description
 * v1.0		  29 Sep, 2023	Abdullah M. Abdullah		  Initial Creation
*********************************************/
#ifndef KPD_PRIVATE_H
#define KPD_PRIVATE_H

static void voidDeactivateAllColumns(void);

#endif