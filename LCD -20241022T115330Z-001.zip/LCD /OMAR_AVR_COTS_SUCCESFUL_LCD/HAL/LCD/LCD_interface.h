#ifndef LCD_INTERFACE_H
#define LCD_INTERFACE_H
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
void LCD_voidInit(void);
void LCD_voidSendData(u8 Copy_u8Data);
void LCD_voidGoToXY(u8 Copy_u8XPosition, u8 Copy_u8YPosition);



#endif
