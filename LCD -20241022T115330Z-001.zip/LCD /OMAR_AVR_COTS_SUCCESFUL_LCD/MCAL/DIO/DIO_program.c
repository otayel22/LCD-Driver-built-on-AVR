/*Library Inclusion*/
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"

/*Lower Layer Inclusion*/

/*Self Layer Inclusion*/

/*Self Files Inclusion*/
#include "DIO_interface.h"
#include "DIO_private.h"
#include "DIO_config.h"


void DIO_voidSetPinDirection(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PinDirection)
{
    if( Copy_u8PortName <= PORTD &&
        Copy_u8PinNumber <= PIN7 &&
        Copy_u8PinDirection <= OUTPUT)
    {
        switch(Copy_u8PortName)
        {
            case PORTA:
                if(Copy_u8PinDirection == INPUT)
                {
                    CLR_BIT(DIO_DDRA, Copy_u8PinNumber);
                }
                else if(Copy_u8PinDirection == OUTPUT)
                {
                    SET_BIT(DIO_DDRA, Copy_u8PinNumber);
                }
                else
                {
                    // Do Nothing
                }
            break;

            case PORTB:
                if(Copy_u8PinDirection == INPUT)
                {
                    CLR_BIT(DIO_DDRB, Copy_u8PinNumber);
                }
                else if(Copy_u8PinDirection == OUTPUT)
                {
                    SET_BIT(DIO_DDRB, Copy_u8PinNumber);
                }
                else
                {
                    /*Raise an error*/
                }
            break;

            case PORTC:
                if(Copy_u8PinDirection == INPUT)
                {
                    CLR_BIT(DIO_DDRC, Copy_u8PinNumber);
                }
                else if(Copy_u8PinDirection == OUTPUT)
                {
                    SET_BIT(DIO_DDRC, Copy_u8PinNumber);
                }
                else
                {
                    /*Raise an error*/
                }
            break;

            case PORTD:
                if(Copy_u8PinDirection == INPUT)
                {
                    CLR_BIT(DIO_DDRD, Copy_u8PinNumber);
                }
                else if(Copy_u8PinDirection == OUTPUT)
                {
                    SET_BIT(DIO_DDRD, Copy_u8PinNumber);
                }
                else
                {
                    /*Raise an error*/
                }
            break;

            default:
            // Do Nothing
            break;
        }
    }
    else
    {
        // Raise An Error
    }
}

void DIO_voidSetPinValue(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PinValue)
{
    switch(Copy_u8PortName)
    {
        case PORTA:
            switch(Copy_u8PinValue)
            {
                case LOW:
                    CLR_BIT(DIO_PORTA, Copy_u8PinNumber);
                break;

                case HIGH:
                    SET_BIT(DIO_PORTA, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;
        
        case PORTB:
            switch(Copy_u8PinValue)
            {
                case LOW:
                    CLR_BIT(DIO_PORTB, Copy_u8PinNumber);
                break;

                case HIGH:
                    SET_BIT(DIO_PORTB, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        case PORTC:
            switch(Copy_u8PinValue)
            {
                case LOW:
                    CLR_BIT(DIO_PORTC, Copy_u8PinNumber);
                break;

                case HIGH:
                    SET_BIT(DIO_PORTC, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;
        
        case PORTD:
            switch(Copy_u8PinValue)
            {
                case LOW:
                    CLR_BIT(DIO_PORTD, Copy_u8PinNumber);
                break;

                case HIGH:
                    SET_BIT(DIO_PORTD, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        default:
        break;
    }
}

void DIO_voidSetPinPullUp(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PullUpState)
{
    switch(Copy_u8PortName)
    {
        case PORTA:
            switch(Copy_u8PullUpState)
            {
                case NOPULLUP:
                    CLR_BIT(DIO_PORTA, Copy_u8PinNumber);
                break;

                case PULLUP:
                    SET_BIT(DIO_PORTA, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        case PORTB:
            switch(Copy_u8PullUpState)
            {
                case NOPULLUP:
                    CLR_BIT(DIO_PORTB, Copy_u8PinNumber);
                break;

                case PULLUP:
                    SET_BIT(DIO_PORTB, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        case PORTC:
            switch(Copy_u8PullUpState)
            {
                case NOPULLUP:
                    CLR_BIT(DIO_PORTC, Copy_u8PinNumber);
                break;

                case PULLUP:
                    SET_BIT(DIO_PORTC, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        case PORTD:
            switch(Copy_u8PullUpState)
            {
                case NOPULLUP:
                    CLR_BIT(DIO_PORTD, Copy_u8PinNumber);
                break;

                case PULLUP:
                    SET_BIT(DIO_PORTD, Copy_u8PinNumber);
                break;

                default:
                break;
            }
        break;

        default:
        break;
    }
}

u8 DIO_u8GetPinValue(u8 Copy_u8PortName, u8 Copy_u8PinNumber)
{
    u8 Local_u8PinValue = 0;
    switch(Copy_u8PortName)
    {
        case PORTA:
            Local_u8PinValue = GET_BIT(DIO_PINA, Copy_u8PinNumber);
        break;

        case PORTB:
            Local_u8PinValue = GET_BIT(DIO_PINB, Copy_u8PinNumber);
        break;

        case PORTC:
            Local_u8PinValue = GET_BIT(DIO_PINC, Copy_u8PinNumber);
        break;
        
        case PORTD:
            Local_u8PinValue = GET_BIT(DIO_PIND, Copy_u8PinNumber);
        break;

        default: 
        break;
    }
    return Local_u8PinValue;
}

void DIO_voidSetPortSpecificDirection(u8 Copy_u8PortName, u8 Copy_PortDirection)
{

}

void DIO_voidSetPortSpecificValue(u8 Copy_u8PortName, u8 Copy_PortValue)
{
    switch(Copy_u8PortName)
    {
        case PORTA:
            DIO_PORTA = Copy_PortValue;
        break;

        case PORTB:
        break;
        
        case PORTC:
        	DIO_PORTC = Copy_PortValue;
        break;

        case PORTD:
        	DIO_PORTD = Copy_PortValue;
        break;

        default:
        break;
    }
}



void DIO_voidSetPortDirection()
{
    
}

void DIO_voidSetPortValue()
{

}


void DIO_voidSetPortPullUp()
{

}

u8 DIO_u8GetPortValue()
{

}




