/*
 * main.c
 *
 *  Created on: Oct 6, 2023
 *      Author: otaye
 */
/*
 * main.c
 *
 *  Created on: Sep 23, 2023
 *      Author: otaye
 */

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"

#include "../../HAL/LCD/LCD_interface.h"
int main(){
	LCD_voidInit();
	LCD_voidSendData('H');
	LCD_voidSendData('i');
	LCD_voidSendData(' ');

	LCD_voidSendData('O');
	LCD_voidSendData('M');
	LCD_voidSendData('A');
	LCD_voidSendData('R');
	LCD_voidSendData(' ');

	LCD_voidSendData('A');
	LCD_voidSendData('L');
	LCD_voidSendData('A');
	LCD_voidSendData('A');
	LCD_voidSendData(' ');
	LCD_voidSendData('T');
	LCD_voidSendData('a');
	LCD_voidSendData('Y');
	LCD_voidGoToXY(1,0);

	LCD_voidSendData('E');
	LCD_voidSendData('L');






	while(1);
	return 0;

}

/*#include "../LIB/BIT_MATH.h"
#include "../LIB/STD_TYPES.h"
#include  "../MCAL/DIO/DIO_interface.h"
#include <util/delay.h>
int main(){
	DIO_voidSetPinDirection(PORTA,PIN0,OUTPUT);
	DIO_voidSetPinDirection(PORTA,PIN1,OUTPUT);
	while(1){

	DIO_voidSetPinValue(PORTA,PIN0,LOW);
	DIO_voidSetPinValue(PORTA,PIN1,LOW);
	_delay_ms(3000);
	DIO_voidSetPinValue(PORTA,PIN0,HIGH);
	DIO_voidSetPinValue(PORTA,PIN1,HIGH);
	_delay_ms(5000);
	}
	return 0;
}
*/
