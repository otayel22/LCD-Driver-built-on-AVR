#include <stdio.h>
#include <stdlib.h>

typedef signed int s32;
typedef unsigned int u32;
typedef unsigned short int u16;
typedef signed short int s16;
typedef unsigned char u8;
typedef signed char s8;

u8* returndigittoString(s32 digit) {
    // Allocate memory for the string
    u8* returnarray = (u8*)malloc(12 * sizeof(u8)); // Allocating space for a 32-bit integer and null terminator
    if (returnarray == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    // Convert the integer to string
    sprintf((char*)returnarray, "%d", digit);
    return returnarray;
}

int main() {
    printf("Enter your number\n");
    s32 digit = 0;
    scanf("%d", &digit);
    u8* digitString = returndigittoString(digit);
    printf("Reverse digit is %s\n", digitString);
    free(digitString); // Free the allocated memory
    return 0;
}
